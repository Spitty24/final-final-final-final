#version 150

// Golden Hour: a gentle warm, yellow cast over everything drawn in the world.
// Nearly every world shader finishes by calling linear_fog, so tinting here covers blocks, water,
// mobs, items in hand, particles, clouds and the sky in one place. The GUI is left alone.
// Make it stronger or weaker by moving these numbers further from or closer to 1.0.
const vec3 GOLDEN_TINT = vec3(1.05, 1.02, 0.86);

vec4 golden_tint(vec4 color) {
    return vec4(clamp(color.rgb * GOLDEN_TINT, 0.0, 1.0), color.a);
}

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    // Item icons in the inventory are drawn with fog switched off (a huge fog start): no tint there.
    if (fogStart > 1.0e10) {
        return inColor;
    }
    if (vertexDistance <= fogStart) {
        return golden_tint(inColor);
    }
    float fogValue = vertexDistance < fogEnd ? smoothstep(fogStart, fogEnd, vertexDistance) : 1.0;
    return golden_tint(vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a));
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 1.0;
    } else if (vertexDistance >= fogEnd) {
        return 0.0;
    }
    return smoothstep(fogEnd, fogStart, vertexDistance);
}

float fog_distance(vec3 pos, int shape) {
    if (shape == 0) {
        return length(pos);
    }
    return max(length(pos.xz), abs(pos.y));
}

// The older form, for any shader that still passes the model-view matrix.
float fog_distance(mat4 modelViewMat, vec3 pos, int shape) {
    vec3 p = (modelViewMat * vec4(pos, 1.0)).xyz;
    return fog_distance(p, shape);
}
